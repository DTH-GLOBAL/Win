package com.keyiflerolsun.entities

data class Tracks(
    val kind: String?,
    val file: String?,
    val label: String?,
)
